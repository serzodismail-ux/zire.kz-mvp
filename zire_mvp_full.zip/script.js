
const psychs = [
  {id:1, name:'Айгерим Садыкова', spec:'Клиникалық психолог', tags:['anxiety','video'], price:10000, rating:4.9, reviews:120, exp:8},
  {id:2, name:'Ерасыл Ахмет', spec:'Когнитивно-поведенческая терапия', tags:['depression','chat'], price:9000, rating:4.8, reviews:86, exp:5},
  {id:3, name:'Дина Нур', spec:'Семейный терапевт', tags:['family','video'], price:12000, rating:4.7, reviews:64, exp:10},
  {id:4, name:'Аян Бек', spec:'Психолог для молодежи', tags:['youth','group'], price:8000, rating:4.6, reviews:40, exp:3}
];

const grid = document.getElementById('grid');
function render(){
  grid.innerHTML='';
  psychs.forEach(p=>{
    const el = document.createElement('div');
    el.className='card psych-card';
    el.innerHTML = `
      <div class="psych-avatar">${p.name.split(' ')[0][0]}${p.name.split(' ')[1] ? p.name.split(' ')[1][0] : ''}</div>
      <div class="psych-meta">
        <h3>${p.name}</h3>
        <p class="muted">${p.spec} · Опыт ${p.exp} лет</p>
        <div class="card-actions">
          <div class="badge">⭐ ${p.rating}</div>
          <div style="margin-left:8px;color:var(--muted)">${p.reviews} отзывов</div>
        </div>
        <div class="price">${p.price.toLocaleString()} ₸ / сеанс</div>
        <div class="card-actions">
          <button class="btn" onclick="openProfile(${p.id})">Подробнее</button>
          <button class="btn small" onclick="bookNow(${p.id})">Записаться</button>
        </div>
      </div>
    `;
    grid.appendChild(el);
  });
}

render();

// filters
document.querySelectorAll('.chip').forEach(ch=>{
  ch.addEventListener('click', ()=> {
    const f = ch.dataset.filter;
    if(f==='all'){ render(); return; }
    const filtered = psychs.filter(p=> p.tags.includes(f) || p.spec.toLowerCase().includes(f));
    grid.innerHTML='';
    filtered.forEach(p=>{
      const el = document.createElement('div');
      el.className='card psych-card';
      el.innerHTML = `
        <div class="psych-avatar">${p.name.split(' ')[0][0]}${p.name.split(' ')[1] ? p.name.split(' ')[1][0] : ''}</div>
        <div class="psych-meta">
          <h3>${p.name}</h3>
          <p class="muted">${p.spec} · Опыт ${p.exp} лет</p>
          <div class="card-actions">
            <div class="badge">⭐ ${p.rating}</div>
            <div style="margin-left:8px;color:var(--muted)">${p.reviews} отзывов</div>
          </div>
          <div class="price">${p.price.toLocaleString()} ₸ / сеанс</div>
          <div class="card-actions">
            <button class="btn" onclick="openProfile(${p.id})">Подробнее</button>
            <button class="btn small" onclick="bookNow(${p.id})">Записаться</button>
          </div>
        </div>
      `;
      grid.appendChild(el);
    });
  });
});

// Modal utilities
const wrap = document.getElementById('modalWrap');
const content = document.getElementById('modalContent');
document.getElementById('closeModal').addEventListener('click', ()=> { wrap.style.display='none'; });

// open profile
function openProfile(id){
  const p = psychs.find(x=>x.id===id);
  content.innerHTML = `
    <h2>${p.name}</h2>
    <p class="muted">${p.spec} · Опыт ${p.exp} лет</p>
    <p>${p.reviews} отзывов · Рейтинг ${p.rating}</p>
    <p class="muted">Стоимость: <strong>${p.price.toLocaleString()} ₸</strong></p>
    <p>Краткое описание: опытный специалист в работе с тревожностью и семейными конфликтами. Практикует КПТ и семейную терапию.</p>
    <div style="margin-top:12px;">
      <button class="btn" onclick="bookNow(${p.id})">Записаться</button>
      <button class="btn small" onclick="wrap.style.display='none'">Закрыть</button>
    </div>
  `;
  wrap.style.display='flex';
}

// booking
function bookNow(id){
  const p = psychs.find(x=>x.id===id);
  content.innerHTML = `
    <h3>Запись к ${p.name}</h3>
    <p class="muted">${p.spec} · ${p.exp} лет опыта</p>
    <p>Стоимость: <strong>${p.price.toLocaleString()} ₸</strong></p>
    <label>Выберите дату и время</label>
    <input type="date" id="bdate" style="padding:8px;margin-top:6px;border-radius:8px;border:1px solid #eef6ff">
    <select id="btime" style="padding:8px;margin-top:6px;border-radius:8px;border:1px solid #eef6ff">
      <option>10:00</option><option>12:00</option><option>15:00</option><option>18:00</option>
    </select>
    <div style="margin-top:12px">
      <button class="btn" id="confirmBtn">Оплатить и подтвердить</button>
      <button class="btn small" onclick="wrap.style.display='none'">Отмена</button>
    </div>
  `;
  wrap.style.display='flex';
  document.getElementById('confirmBtn').addEventListener('click', ()=>{
    const date = document.getElementById('bdate').value || 'сегодня';
    const time = document.getElementById('btime').value;
    alert(`Сеанс подтверждён на ${date} в ${time}.`);
    wrap.style.display='none';
  });
}

// AI simulation
function openAI(){
  content.innerHTML = `
    <h3>ZireAI — ассистент</h3>
    <div style="margin-top:8px">
      <textarea id="aiText" placeholder="Опишите ваши чувства..." style="width:100%;min-height:90px;padding:8px;border-radius:8px;border:1px solid #eef6ff"></textarea>
      <div style="margin-top:8px;">
        <button class="btn" id="aiSend">Отправить</button>
        <button class="btn small" onclick="wrap.style.display='none'">Закрыть</button>
      </div>
      <div id="aiResp" style="margin-top:10px;color:var(--muted)"></div>
    </div>
  `;
  wrap.style.display='flex';
  setTimeout(()=> document.getElementById('aiText').focus(),300);
  document.getElementById('aiSend').addEventListener('click', ()=>{
    const t = document.getElementById('aiText').value.toLowerCase();
    const r = document.getElementById('aiResp');
    r.innerText = 'Анализирую...';
    setTimeout(()=>{
      if(t.includes('трев') || t.includes('бесп')) r.innerText = 'Похоже, вы тревожитесь. Рекомендую дыхательное упражнение 4-4-6 и мини-сеанс.';
      else if(t.includes('ужас') || t.includes('депресс')) r.innerText = 'Возможно, стоит записаться на курс из 4 сессий. Могу предложить подходящих специалистов.';
      else r.innerText = 'Рекомендую пройти короткий тест GAD-7 или начать мини-сеанс.';
    },800);
  });
}

// bind AI openers
document.getElementById('openAI').addEventListener('click', openAI);
document.getElementById('openAI2').addEventListener('click', openAI);
document.getElementById('openAI').addEventListener('keypress', ()=>{});
document.getElementById('openAI2').addEventListener('keypress', ()=>{});
document.getElementById('openAI').addEventListener('keydown', ()=>{});

// quick buttons
document.querySelectorAll('.quick-btn').forEach(b=>{
  b.addEventListener('click', (e)=>{
    const a = e.target.dataset.action;
    if(a==='ai') openAI();
    else if(a==='test') alert('Открываем тесты (демо).');
    else if(a==='session') alert('Запуск мини-сеанса (демо).');
    else if(a==='group') alert('Список групп (демо).');
  });
});

// header search
document.getElementById('searchBtn').addEventListener('click', ()=>{
  const q = document.getElementById('mainSearch').value.trim().toLowerCase();
  if(!q) { render(); return; }
  const filtered = psychs.filter(p=> p.name.toLowerCase().includes(q) || p.spec.toLowerCase().includes(q));
  grid.innerHTML='';
  filtered.forEach(p=>{
    const el = document.createElement('div');
    el.className='card psych-card';
    el.innerHTML = `
      <div class="psych-avatar">${p.name.split(' ')[0][0]}${p.name.split(' ')[1] ? p.name.split(' ')[1][0] : ''}</div>
      <div class="psych-meta">
        <h3>${p.name}</h3>
        <p class="muted">${p.spec} · Опыт ${p.exp} лет</p>
        <div class="card-actions">
          <div class="badge">⭐ ${p.rating}</div>
          <div style="margin-left:8px;color:var(--muted)">${p.reviews} отзывов</div>
        </div>
        <div class="price">${p.price.toLocaleString()} ₸ / сеанс</div>
        <div class="card-actions">
          <button class="btn" onclick="openProfile(${p.id})">Подробнее</button>
          <button class="btn small" onclick="bookNow(${p.id})">Записаться</button>
        </div>
      </div>
    `;
    grid.appendChild(el);
  });
});
